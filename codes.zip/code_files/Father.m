//
//  Father.m
//  Objc-Trip
//
//  Created by binhuang on 2022/4/15.
//

#import "Father.h"

@implementation Father

@end
